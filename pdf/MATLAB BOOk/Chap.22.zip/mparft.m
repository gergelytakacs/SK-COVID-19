%%%%%%%%%%%%%%%%%%%%%%% mparst3.m %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%		
%
%	Usage:
%		mparst3
%
%	Sets up
%		loadat, residfn     
%
%	for mparft.m for a specific case:  plagdat.m, resid3.m
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
echo off;
loadat = 'plagdat';
residfn= 'resid3';
disp('mparft set up for  plague data')
disp('using plagdat and resid3')

